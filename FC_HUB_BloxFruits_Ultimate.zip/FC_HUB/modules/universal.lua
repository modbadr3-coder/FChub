--!strict

--[[ FC HUB Universal Module ]]
-- This module contains functionalities that are applicable across all Roblox games.
-- It demonstrates how to add features to the main UI window.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

-- Ensure FC_HUB global table exists
_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Check if UI is loaded before attempting to create UI elements
if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local UniversalTab = _G.FC_HUB.UniversalTab -- Use the MainTab passed from main.lua

    -- Example: WalkSpeed Slider
    UniversalTab:CreateSlider({
        Name = "سرعة اللاعب (WalkSpeed)",
        Range = {16, 500},
        Increment = 1,
        Suffix = "Speed",
        CurrentValue = _G.FC_HUB.Config.WalkSpeed or 16,
        Flag = "WalkSpeedSlider",
        Callback = function(Value)
            _G.FC_HUB.Config.WalkSpeed = Value
            if LocalPlayer and LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid") then
                LocalPlayer.Character.Humanoid.WalkSpeed = Value
            end
        end,
    })

    -- Example: Infinite Jump Toggle
    UniversalTab:CreateToggle({
        Name = "القفز اللانهائي",
        CurrentValue = _G.FC_HUB.Config.InfiniteJump or false,
        Flag = "InfiniteJumpToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.InfiniteJump = Value
            print("Universal Module: Infinite Jump set to: " .. tostring(Value))
        end,
    })

    -- Implement Infinite Jump logic (if not already in main.lua)
    game:GetService("UserInputService").JumpRequest:Connect(function()
        if _G.FC_HUB.Config.InfiniteJump and LocalPlayer and LocalPlayer.Character then
            local humanoid = LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
            end
        end
    end)

    UniversalTab:CreateLabel("تم تحميل الوظائف العامة بنجاح.")

    print("FC HUB Universal Module: UI elements created.")
else
    warn("FC HUB Universal Module: UI not available. Running in console-only mode.")
    -- Still apply settings if UI is not available
    if _G.FC_HUB.Config.WalkSpeed then
        if LocalPlayer and LocalPlayer.Character and LocalPlayer.Character:FindFirstChildOfClass("Humanoid") then
            LocalPlayer.Character.Humanoid.WalkSpeed = _G.FC_HUB.Config.WalkSpeed
        end
    end
    -- Infinite Jump logic is already handled by the event listener, just need to set the config value
end

print("FC HUB Universal Module: Loaded.")
