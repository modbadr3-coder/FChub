--!strict

--[[ FC HUB Piggy Module ]]
-- This module contains functionalities specific to the Piggy game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Piggy Specific Configuration Defaults
_G.FC_HUB.Config.Piggy_SeePiggy = _G.FC_HUB.Config.Piggy_SeePiggy or false
_G.FC_HUB.Config.Piggy_TeleportToExit = _G.FC_HUB.Config.Piggy_TeleportToExit or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local PiggyTab = _G.FC_HUB.MainWindow:CreateTab("Piggy", 4483362458) -- Home icon for now

    PiggyTab:CreateToggle({
        Name = "رؤية Piggy (See Piggy)",
        CurrentValue = _G.FC_HUB.Config.Piggy_SeePiggy,
        Flag = "Piggy_SeePiggyToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.Piggy_SeePiggy = Value
            print("Piggy See Piggy: " .. tostring(Value))
            -- Logic to highlight or show Piggy
        end,
    })

    PiggyTab:CreateButton({
        Name = "الانتقال إلى المخرج",
        Callback = function()
            print("Piggy: Teleporting to exit...")
            -- Logic for teleporting to the exit
        end,
    })

    PiggyTab:CreateLabel("تم تحميل وظائف Piggy بنجاح.")
    print("FC HUB Piggy Module: UI elements created.")
else
    warn("FC HUB Piggy Module: UI not available. Running in console-only mode.")
end

print("FC HUB Piggy Module: Loaded.")
