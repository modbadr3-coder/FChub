--!strict

--[[ FC HUB Natural Disaster Survival Module ]]
-- This module contains functionalities specific to the Natural Disaster Survival game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Natural Disaster Survival Specific Configuration Defaults
_G.FC_HUB.Config.NDS_GodMode = _G.FC_HUB.Config.NDS_GodMode or false
_G.FC_HUB.Config.NDS_TeleportToSafeSpot = _G.FC_HUB.Config.NDS_TeleportToSafeSpot or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local NDSTab = _G.FC_HUB.MainWindow:CreateTab("Natural Disaster Survival", 4483362458) -- Home icon for now

    NDSTab:CreateToggle({
        Name = "وضع الخلود (God Mode)",
        CurrentValue = _G.FC_HUB.Config.NDS_GodMode,
        Flag = "NDS_GodModeToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.NDS_GodMode = Value
            print("NDS God Mode: " .. tostring(Value))
            -- Logic for God Mode
        end,
    })

    NDSTab:CreateButton({
        Name = "الانتقال إلى مكان آمن",
        Callback = function()
            print("NDS: Teleporting to safe spot...")
            -- Logic for teleporting to a safe spot
        end,
    })

    NDSTab:CreateLabel("تم تحميل وظائف Natural Disaster Survival بنجاح.")
    print("FC HUB Natural Disaster Survival Module: UI elements created.")
else
    warn("FC HUB Natural Disaster Survival Module: UI not available. Running in console-only mode.")
end

print("FC HUB Natural Disaster Survival Module: Loaded.")
