--!strict

--[[ FC HUB Adopt Me! Module ]]
-- This module contains functionalities specific to the Adopt Me! game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Adopt Me! Specific Configuration Defaults
_G.FC_HUB.Config.AdoptMe_AutoFarmPets = _G.FC_HUB.Config.AdoptMe_AutoFarmPets or false
_G.FC_HUB.Config.AdoptMe_AutoCollectMoney = _G.FC_HUB.Config.AdoptMe_AutoCollectMoney or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local AdoptMeTab = _G.FC_HUB.MainWindow:CreateTab("Adopt Me!", 4483362458) -- Home icon for now

    AdoptMeTab:CreateToggle({
        Name = "تفعيل Auto Farm للحيوانات الأليفة",
        CurrentValue = _G.FC_HUB.Config.AdoptMe_AutoFarmPets,
        Flag = "AdoptMe_AutoFarmPetsToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.AdoptMe_AutoFarmPets = Value
            print("Adopt Me! Auto Farm Pets: " .. tostring(Value))
            -- Logic for auto farming pets
        end,
    })

    AdoptMeTab:CreateToggle({
        Name = "تفعيل جمع الأموال تلقائياً",
        CurrentValue = _G.FC_HUB.Config.AdoptMe_AutoCollectMoney,
        Flag = "AdoptMe_AutoCollectMoneyToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.AdoptMe_AutoCollectMoney = Value
            print("Adopt Me! Auto Collect Money: " .. tostring(Value))
            -- Logic for auto collecting money
        end,
    })

    AdoptMeTab:CreateLabel("تم تحميل وظائف Adopt Me! بنجاح.")
    print("FC HUB Adopt Me! Module: UI elements created.")
else
    warn("FC HUB Adopt Me! Module: UI not available. Running in console-only mode.")
end

print("FC HUB Adopt Me! Module: Loaded.")
