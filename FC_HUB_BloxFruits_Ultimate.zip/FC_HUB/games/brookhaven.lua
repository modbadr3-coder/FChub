--!strict

--[[ FC HUB Brookhaven RP Module ]]
-- This module contains functionalities specific to the Brookhaven RP game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Brookhaven RP Specific Configuration Defaults
_G.FC_HUB.Config.Brookhaven_AutoMoney = _G.FC_HUB.Config.Brookhaven_AutoMoney or false
_G.FC_HUB.Config.Brookhaven_TeleportToHouses = _G.FC_HUB.Config.Brookhaven_TeleportToHouses or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local BrookhavenTab = _G.FC_HUB.MainWindow:CreateTab("Brookhaven RP", 4483362458) -- Home icon for now

    BrookhavenTab:CreateToggle({
        Name = "تفعيل جمع الأموال تلقائياً",
        CurrentValue = _G.FC_HUB.Config.Brookhaven_AutoMoney,
        Flag = "Brookhaven_AutoMoneyToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.Brookhaven_AutoMoney = Value
            print("Brookhaven Auto Money: " .. tostring(Value))
            -- Logic for auto collecting money
        end,
    })

    BrookhavenTab:CreateButton({
        Name = "الانتقال إلى المنازل",
        Callback = function()
            print("Brookhaven: Teleporting to random house...")
            -- Logic for teleporting to houses
        end,
    })

    BrookhavenTab:CreateLabel("تم تحميل وظائف Brookhaven RP بنجاح.")
    print("FC HUB Brookhaven RP Module: UI elements created.")
else
    warn("FC HUB Brookhaven RP Module: UI not available. Running in console-only mode.")
end

print("FC HUB Brookhaven RP Module: Loaded.")
