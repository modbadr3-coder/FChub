--!strict

--[[ FC HUB Tower of Hell Module ]]
-- This module contains functionalities specific to the Tower of Hell game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Tower of Hell Specific Configuration Defaults
_G.FC_HUB.Config.ToH_AutoWin = _G.FC_HUB.Config.ToH_AutoWin or false
_G.FC_HUB.Config.ToH_NoClip = _G.FC_HUB.Config.ToH_NoClip or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local ToHTab = _G.FC_HUB.MainWindow:CreateTab("Tower of Hell", 4483362458) -- Home icon for now

    ToHTab:CreateToggle({
        Name = "تفعيل الفوز التلقائي",
        CurrentValue = _G.FC_HUB.Config.ToH_AutoWin,
        Flag = "ToH_AutoWinToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.ToH_AutoWin = Value
            print("Tower of Hell Auto Win: " .. tostring(Value))
            -- Logic for auto winning (e.g., teleport to top)
        end,
    })

    ToHTab:CreateToggle({
        Name = "اختراق الجدران (NoClip)",
        CurrentValue = _G.FC_HUB.Config.ToH_NoClip,
        Flag = "ToH_NoClipToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.ToH_NoClip = Value
            print("Tower of Hell NoClip: " .. tostring(Value))
            -- Logic for NoClip
        end,
    })

    ToHTab:CreateLabel("تم تحميل وظائف Tower of Hell بنجاح.")
    print("FC HUB Tower of Hell Module: UI elements created.")
else
    warn("FC HUB Tower of Hell Module: UI not available. Running in console-only mode.")
end

print("FC HUB Tower of Hell Module: Loaded.")
