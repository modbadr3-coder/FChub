--!strict

--[[ FC HUB All Star Tower Defense Module ]]
-- This module contains functionalities specific to the All Star Tower Defense game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- All Star Tower Defense Specific Configuration Defaults
_G.FC_HUB.Config.ASTD_AutoPlaceTowers = _G.FC_HUB.Config.ASTD_AutoPlaceTowers or false
_G.FC_HUB.Config.ASTD_AutoUpgradeTowers = _G.FC_HUB.Config.ASTD_AutoUpgradeTowers or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local ASTDTab = _G.FC_HUB.MainWindow:CreateTab("All Star Tower Defense", 4483362458) -- Home icon for now

    ASTDTab:CreateToggle({
        Name = "تفعيل وضع الأبراج تلقائياً",
        CurrentValue = _G.FC_HUB.Config.ASTD_AutoPlaceTowers,
        Flag = "ASTD_AutoPlaceTowersToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.ASTD_AutoPlaceTowers = Value
            print("ASTD Auto Place Towers: " .. tostring(Value))
            -- Logic for auto placing towers
        end,
    })

    ASTDTab:CreateToggle({
        Name = "تفعيل ترقية الأبراج تلقائياً",
        CurrentValue = _G.FC_HUB.Config.ASTD_AutoUpgradeTowers,
        Flag = "ASTD_AutoUpgradeTowersToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.ASTD_AutoUpgradeTowers = Value
            print("ASTD Auto Upgrade Towers: " .. tostring(Value))
            -- Logic for auto upgrading towers
        end,
    })

    ASTDTab:CreateLabel("تم تحميل وظائف All Star Tower Defense بنجاح.")
    print("FC HUB All Star Tower Defense Module: UI elements created.")
else
    warn("FC HUB All Star Tower Defense Module: UI not available. Running in console-only mode.")
end

print("FC HUB All Star Tower Defense Module: Loaded.")
