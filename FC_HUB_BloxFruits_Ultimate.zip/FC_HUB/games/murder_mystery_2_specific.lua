--!strict

--[[ FC HUB Murder Mystery 2 Specific Module ]]
-- This module contains functionalities specific to the Murder Mystery 2 game.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

-- Murder Mystery 2 Specific Configuration Defaults
_G.FC_HUB.Config.MM2_AutoCollectCoins = _G.FC_HUB.Config.MM2_AutoCollectCoins or false
_G.FC_HUB.Config.MM2_SeeMurderer = _G.FC_HUB.Config.MM2_SeeMurderer or false
_G.FC_HUB.Config.MM2_TeleportToGun = _G.FC_HUB.Config.MM2_TeleportToGun or false

if _G.FC_HUB.UI and _G.FC_HUB.MainWindow then
    local MM2Tab = _G.FC_HUB.MainWindow:CreateTab("Murder Mystery 2", 4483362458) -- Home icon for now

    MM2Tab:CreateToggle({
        Name = "تفعيل جمع العملات تلقائياً",
        CurrentValue = _G.FC_HUB.Config.MM2_AutoCollectCoins,
        Flag = "MM2_AutoCollectCoinsToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.MM2_AutoCollectCoins = Value
            print("MM2 Auto Collect Coins: " .. tostring(Value))
            -- Logic for auto collecting coins
        end,
    })

    MM2Tab:CreateToggle({
        Name = "رؤية القاتل (See Murderer)",
        CurrentValue = _G.FC_HUB.Config.MM2_SeeMurderer,
        Flag = "MM2_SeeMurdererToggle",
        Callback = function(Value)
            _G.FC_HUB.Config.MM2_SeeMurderer = Value
            print("MM2 See Murderer: " .. tostring(Value))
            -- Logic to highlight or show murderer
        end,
    })

    MM2Tab:CreateButton({
        Name = "الانتقال إلى المسدس",
        Callback = function()
            print("MM2: Teleporting to gun...")
            -- Logic to teleport to the gun
        end,
    })

    MM2Tab:CreateLabel("تم تحميل وظائف Murder Mystery 2 بنجاح.")
    print("FC HUB Murder Mystery 2 Module: UI elements created.")
else
    warn("FC HUB Murder Mystery 2 Module: UI not available. Running in console-only mode.")
end

print("FC HUB Murder Mystery 2 Module: Loaded.")
