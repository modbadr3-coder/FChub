--!strict

--[[ FC HUB Loader ]]
-- This script is responsible for loading the main FC HUB script from a remote source.
-- It also handles basic error reporting and ensures the latest version is always used.

local FC_HUB_VERSION = "1.0.0" -- Current version of the loader
local REMOTE_SCRIPT_URL = "https://raw.githubusercontent.com/YourUsername/FC_HUB/main/main.lua" -- Replace with your GitHub raw URL

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local function fetchScript(url)
    local success, result = pcall(function()
        return game:HttpGet(url, true)
    end)
    if not success then
        warn("FC HUB Loader: Failed to fetch script from " .. url .. ": " .. result)
        return nil
    end
    return result
end

local function executeScript(scriptContent)
    local success, err = pcall(function()
        local func = loadstring(scriptContent, "FC_HUB_Main")
        if func then
            func()
        else
            error("FC HUB Loader: Failed to load script content.")
        end
    end)
    if not success then
        warn("FC HUB Loader: Error executing main script: " .. err)
        -- Optionally, notify the user via a simple UI element
    end
end

local function init()
    print("FC HUB Loader: Initializing (Version: " .. FC_HUB_VERSION .. ")")

    local scriptContent = fetchScript(REMOTE_SCRIPT_URL)
    if scriptContent then
        executeScript(scriptContent)
    else
        warn("FC HUB Loader: Could not load main script. Please check your internet connection or the script URL.")
    end
end

init()
