--!strict

--[[ FC HUB Configuration Manager ]]
-- This module handles saving and loading user configurations.
-- In a real scenario, this would interact with a persistent storage solution.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = _G.FC_HUB.Config or {}

local CONFIG_FOLDER_NAME = "FCHubData"
local CONFIG_FILE_NAME = "Config.json"

local function getSavePath()
    -- In a real exploit environment, you'd use a persistent storage function
    -- For demonstration, we'll simulate a path.
    return "workspace://" .. CONFIG_FOLDER_NAME .. "/" .. CONFIG_FILE_NAME
end

function _G.FC_HUB.ConfigManager_Load()
    print("FC HUB Config: Attempting to load configuration...")
    local success, content = pcall(function()
        -- Simulate loading from a file. In a real exploit, this would be game:HttpGet or similar.
        -- For now, we'll return a default or previously saved string.
        -- return game:HttpGet(getSavePath(), true) -- This would be the actual call
        return nil -- Simulate no saved config for now
    end)

    if success and content and content ~= "" then
        local decodedSuccess, decodedConfig = pcall(game.HttpService.JSONDecode, game.HttpService, content)
        if decodedSuccess and type(decodedConfig) == "table" then
            _G.FC_HUB.Config = decodedConfig
            print("FC HUB Config: Configuration loaded successfully.")
        else
            warn("FC HUB Config: Failed to decode saved configuration: " .. (decodedConfig or "Unknown error"))
            _G.FC_HUB.Config = {} -- Reset to default
        end
    else
        print("FC HUB Config: No saved configuration found or failed to retrieve. Using default.")
        _G.FC_HUB.Config = {} -- Initialize as empty table for defaults to apply
    end
end

function _G.FC_HUB.ConfigManager_Save()
    print("FC HUB Config: Attempting to save configuration...")
    local encodedSuccess, encodedConfig = pcall(game.HttpService.JSONEncode, game.HttpService, _G.FC_HUB.Config)
    if encodedSuccess then
        -- Simulate saving to a file. In a real exploit, this would be game:HttpPost or similar.
        -- game:HttpPost(getSavePath(), encodedConfig) -- This would be the actual call
        print("FC HUB Config: Configuration saved successfully (simulated).")
    else
        warn("FC HUB Config: Failed to encode configuration for saving: " .. (encodedConfig or "Unknown error"))
    end
end

-- Initialize default configuration values if not already set
_G.FC_HUB.Config.WalkSpeed = _G.FC_HUB.Config.WalkSpeed or 16
_G.FC_HUB.Config.InfiniteJump = _G.FC_HUB.Config.InfiniteJump or false
_G.FC_HUB.Config.BloxFruits_AutoFarmLevel = _G.FC_HUB.Config.BloxFruits_AutoFarmLevel or false
_G.FC_HUB.Config.BloxFruits_AutoFarmMastery = _G.FC_HUB.Config.BloxFruits_AutoFarmMastery or false
_G.FC_HUB.Config.BloxFruits_AutoFarmMaterials = _G.FC_HUB.Config.BloxFruits_AutoFarmMaterials or false
_G.FC_HUB.Config.BloxFruits_FarmMobName = _G.FC_HUB.Config.BloxFruits_FarmMobName or ""
_G.FC_HUB.Config.BloxFruits_FarmWeapon = _G.FC_HUB.Config.BloxFruits_FarmWeapon or "Sword"
_G.FC_HUB.Config.BloxFruits_AutoQuest = _G.FC_HUB.Config.BloxFruits_AutoQuest or false
_G.FC_HUB.Config.BloxFruits_AutoBuyWeapon = _G.FC_HUB.Config.BloxFruits_AutoBuyWeapon or false
_G.FC_HUB.Config.BloxFruits_AutoBuyFruit = _G.FC_HUB.Config.BloxFruits_AutoBuyFruit or false
_G.FC_HUB.Config.BloxFruits_AutoStats = _G.FC_HUB.Config.BloxFruits_AutoStats or false
_G.FC_HUB.Config.BloxFruits_StatsPriority = _G.FC_HUB.Config.BloxFruits_StatsPriority or "Melee"
_G.FC_HUB.Config.PetSim99AutoCollectCoins = _G.FC_HUB.Config.PetSim99AutoCollectCoins or false
_G.FC_HUB.Config.UserKey = _G.FC_HUB.Config.UserKey or ""

-- Advanced Exploits Config
_G.FC_HUB.Config.ESP_Enabled = _G.FC_HUB.Config.ESP_Enabled or false
_G.FC_HUB.Config.ESP_TeamCheck = _G.FC_HUB.Config.ESP_TeamCheck or true
_G.FC_HUB.Config.ESP_Box = _G.FC_HUB.Config.ESP_Box or false
_G.FC_HUB.Config.ESP_Name = _G.FC_HUB.Config.ESP_Name or false
_G.FC_HUB.Config.ESP_Health = _G.FC_HUB.Config.ESP_Health or false
_G.FC_HUB.Config.ESP_Tracers = _G.FC_HUB.Config.ESP_Tracers or false
_G.FC_HUB.Config.Aimbot_Enabled = _G.FC_HUB.Config.Aimbot_Enabled or false
_G.FC_HUB.Config.Aimbot_TargetPart = _G.FC_HUB.Config.Aimbot_TargetPart or "Head"
_G.FC_HUB.Config.Aimbot_FOV = _G.FC_HUB.Config.Aimbot_FOV or 90
_G.FC_HUB.Config.Aimbot_Smoothness = _G.FC_HUB.Config.Aimbot_Smoothness or 0.1
_G.FC_HUB.Config.Fly_Enabled = _G.FC_HUB.Config.Fly_Enabled or false
_G.FC_HUB.Config.Fly_Speed = _G.FC_HUB.Config.Fly_Speed or 20
_G.FC_HUB.Config.Fly_NoClip = _G.FC_HUB.Config.Fly_NoClip or false

-- RPG Template Config
_G.FC_HUB.Config.RPG_AutoQuest = _G.FC_HUB.Config.RPG_AutoQuest or false
_G.FC_HUB.Config.RPG_AutoFarmMobs = _G.FC_HUB.Config.RPG_AutoFarmMobs or false
_G.FC_HUB.Config.RPG_TeleportToQuest = _G.FC_HUB.Config.RPG_TeleportToQuest or false
_G.FC_HUB.Config.RPG_GodMode = _G.FC_HUB.Config.RPG_GodMode or false
_G.FC_HUB.Config.RPG_NoClip = _G.FC_HUB.Config.RPG_NoClip or false

-- FPS Template Config
_G.FC_HUB.Config.FPS_NoRecoil = _G.FC_HUB.Config.FPS_NoRecoil or false
_G.FC_HUB.Config.FPS_NoSpread = _G.FC_HUB.Config.FPS_NoSpread or false
_G.FC_HUB.Config.FPS_TriggerBot = _G.FC_HUB.Config.FPS_TriggerBot or false
_G.FC_HUB.Config.FPS_Wallhack = _G.FC_HUB.Config.FPS_Wallhack or false
_G.FC_HUB.Config.FPS_FOVChanger = _G.FC_HUB.Config.FPS_FOVChanger or 70

-- Simulator Template Config
_G.FC_HUB.Config.Simulator_AutoCollect = _G.FC_HUB.Config.Simulator_AutoCollect or false
_G.FC_HUB.Config.Simulator_AutoSell = _G.FC_HUB.Config.Simulator_AutoSell or false
_G.FC_HUB.Config.Simulator_AutoHatch = _G.FC_HUB.Config.Simulator_AutoHatch or false
_G.FC_HUB.Config.Simulator_WalkSpeedBoost = _G.FC_HUB.Config.Simulator_WalkSpeedBoost or 1

-- Adopt Me! Config
_G.FC_HUB.Config.AdoptMe_AutoFarmPets = _G.FC_HUB.Config.AdoptMe_AutoFarmPets or false
_G.FC_HUB.Config.AdoptMe_AutoCollectMoney = _G.FC_HUB.Config.AdoptMe_AutoCollectMoney or false

-- Brookhaven RP Config
_G.FC_HUB.Config.Brookhaven_AutoMoney = _G.FC_HUB.Config.Brookhaven_AutoMoney or false
_G.FC_HUB.Config.Brookhaven_TeleportToHouses = _G.FC_HUB.Config.Brookhaven_TeleportToHouses or false

-- Tower of Hell Config
_G.FC_HUB.Config.ToH_AutoWin = _G.FC_HUB.Config.ToH_AutoWin or false
_G.FC_HUB.Config.ToH_NoClip = _G.FC_HUB.Config.ToH_NoClip or false

-- Murder Mystery 2 Specific Config
_G.FC_HUB.Config.MM2_AutoCollectCoins = _G.FC_HUB.Config.MM2_AutoCollectCoins or false
_G.FC_HUB.Config.MM2_SeeMurderer = _G.FC_HUB.Config.MM2_SeeMurderer or false
_G.FC_HUB.Config.MM2_TeleportToGun = _G.FC_HUB.Config.MM2_TeleportToGun or false

-- Jailbreak Config
_G.FC_HUB.Config.Jailbreak_AutoRob = _G.FC_HUB.Config.Jailbreak_AutoRob or false
_G.FC_HUB.Config.Jailbreak_TeleportToVault = _G.FC_HUB.Config.Jailbreak_TeleportToVault or false

-- Piggy Config
_G.FC_HUB.Config.Piggy_SeePiggy = _G.FC_HUB.Config.Piggy_SeePiggy or false
_G.FC_HUB.Config.Piggy_TeleportToExit = _G.FC_HUB.Config.Piggy_TeleportToExit or false

-- Natural Disaster Survival Config
_G.FC_HUB.Config.NDS_GodMode = _G.FC_HUB.Config.NDS_GodMode or false
_G.FC_HUB.Config.NDS_TeleportToSafeSpot = _G.FC_HUB.Config.NDS_TeleportToSafeSpot or false

-- All Star Tower Defense Config
_G.FC_HUB.Config.ASTD_AutoPlaceTowers = _G.FC_HUB.Config.ASTD_AutoPlaceTowers or false
_G.FC_HUB.Config.ASTD_AutoUpgradeTowers = _G.FC_HUB.Config.ASTD_AutoUpgradeTowers or false

-- Blox Fruits PvP and Sea Events Config
_G.FC_HUB.Config.BloxFruits_AutoPvP = _G.FC_HUB.Config.BloxFruits_AutoPvP or false
_G.FC_HUB.Config.BloxFruits_AutoSeaBeast = _G.FC_HUB.Config.BloxFruits_AutoSeaBeast or false
_G.FC_HUB.Config.BloxFruits_AutoShipFarm = _G.FC_HUB.Config.BloxFruits_AutoShipFarm or false
_G.FC_HUB.Config.BloxFruits_AutoKraken = _G.FC_HUB.Config.BloxFruits_AutoKraken or false
_G.FC_HUB.Config.BloxFruits_PvPTarget = _G.FC_HUB.Config.BloxFruits_PvPTarget or "Closest"

print("FC HUB Config Manager: Loaded.")
