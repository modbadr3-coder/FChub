--!strict

--[[ FC HUB Main Script ]]
-- This is the main entry point for the FC HUB. It handles UI initialization, game detection,
-- and dynamic loading of modules based on the current game or universal functionalities.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Global table for FC HUB functionalities
_G.FC_HUB = _G.FC_HUB or {}
_G.FC_HUB.Config = {}
_G.FC_HUB.Modules = {}
_G.FC_HUB.UI = nil

-- Configuration for game-specific modules
local GAME_MODULES = {
    -- RPG Games
    [2753915549] = "rpg_template", -- Blox Fruits
    [3623096089] = "rpg_template", -- Shindo Life
    [4924922222] = "rpg_template", -- Anime Fighters Simulator (Hypothetical PlaceId)
    [687227449] = "rpg_template", -- Grand Piece Online
    [2077696450] = "rpg_template", -- Royale High (can have RPG elements)

    -- FPS Games
    [744942363] = "fps_template", -- Arsenal
    [2641974547] = "fps_template", -- Phantom Forces
    [8888888888] = "fps_template", -- MM2 (Murder Mystery 2 - can use FPS elements) (Hypothetical PlaceId)
    [7777777777] = "fps_template", -- BedWars (can use FPS elements) (Hypothetical PlaceId)

    -- Simulator Games
    [9999999999] = "simulator_template", -- Pet Simulator 99 (Hypothetical PlaceId)
    [2590244307] = "simulator_template", -- Bee Swarm Simulator
    [181440663] = "simulator_template", -- Work at a Pizza Place
    [138228964] = "simulator_template", -- Theme Park Tycoon 2

    -- Other Games (can have specific modules or use universal features)
    [606849621] = "adopt_me", -- Adopt Me! (Requires specific module)
    [2924139470] = "brookhaven", -- Brookhaven RP (Requires specific module)
    [286090429] = "tower_of_hell", -- Tower of Hell (Requires specific module)
    [6284583030] = "murder_mystery_2_specific", -- Murder Mystery 2 (Specific module if different from FPS template)
    [1600503] = "jailbreak", -- Jailbreak (Requires specific module)
    [4442272183] = "piggy", -- Piggy (Requires specific module)
    [196208625] = "natural_disaster_survival", -- Natural Disaster Survival (Requires specific module)
    [5374135282] = "all_star_tower_defense", -- All Star Tower Defense (Requires specific module)
    [7350000000] = "doors", -- DOORS (Hypothetical PlaceId, requires specific module)
    [9999999998] = "adopt_me_new", -- Adopt Me! (Hypothetical New PlaceId, requires specific module)

    -- Add more game PlaceIds and their corresponding module names here
    -- [OTHER_GAME_PLACEID] = "other_game_module_name",
}

-- Function to load UI Library (e.g., Rayfield)
local function loadUILibrary()
    print("FC HUB: Attempting to load UI Library...")
    local success, Rayfield = pcall(function()
        -- This URL should point to the raw content of the Rayfield library
        -- For a real project, you'd host this securely or embed it.
        return loadstring(game:HttpGet("https://sirius.menu/rayfield"))()
    end)

    if success and Rayfield then
        _G.FC_HUB.UI = Rayfield
        print("FC HUB: Rayfield UI Library loaded successfully.")
        return true
    else
        warn("FC HUB: Failed to load Rayfield UI Library: " .. (Rayfield or "Unknown error"))
        -- Fallback to a simpler UI or error message
        return false
    end
end

-- Function to load configuration
local function loadConfig()
    print("FC HUB: Loading configuration...")
    loadModule("config/config") -- Load the config manager module
    _G.FC_HUB.ConfigManager_Load() -- Call the load function from the config manager
    print("FC HUB: Configuration loaded.")
end

-- Function to save configuration
local function saveConfig()
    print("FC HUB: Saving configuration...")
    _G.FC_HUB.ConfigManager_Save() -- Call the save function from the config manager
    print("FC HUB: Configuration saved.")
end

-- Function to load a module from a given path
local function loadModule(modulePath)
    local fullPath = "https://raw.githubusercontent.com/YourUsername/FC_HUB/main/" .. modulePath .. ".lua"
    local success, scriptContent = pcall(function()
        return game:HttpGet(fullPath, true)
    end)

    if success and scriptContent then
        local moduleSuccess, err = pcall(function()
            local func = loadstring(scriptContent, modulePath)
            if func then
                func()
            else
                error("FC HUB: Failed to load module content for " .. modulePath .. ".")
            end
        end)
        if not moduleSuccess then
            warn("FC HUB: Error executing module " .. modulePath .. ": " .. err)
        else
            print("FC HUB: Module " .. modulePath .. " loaded successfully.")
        end
    else
        warn("FC HUB: Failed to fetch module from " .. fullPath .. ": " .. (scriptContent or "Unknown error"))
    end
end

-- Function to detect current game and load game-specific modules
local function loadGameModules()
    local placeId = game.PlaceId
    print("FC HUB: Detecting game (PlaceId: " .. placeId .. ")...")

    -- Load universal modules first
    loadModule("modules/universal")

    local gameModuleName = GAME_MODULES[placeId]
    if gameModuleName then
        print("FC HUB: Loading game-specific modules for PlaceId " .. placeId .. " (" .. gameModuleName .. ")...")
        -- Check if the module is a template or a specific game module
        if gameModuleName == "rpg_template" then
            loadModule("games/rpg_template")
        elseif gameModuleName == "fps_template" then
            loadModule("games/fps_template")
        elseif gameModuleName == "simulator_template" then
            loadModule("games/simulator_template")
        elseif gameModuleName == "adopt_me" then
            loadModule("games/adopt_me")
        elseif gameModuleName == "brookhaven" then
            loadModule("games/brookhaven")
        elseif gameModuleName == "tower_of_hell" then
            loadModule("games/tower_of_hell")
        elseif gameModuleName == "murder_mystery_2_specific" then
            loadModule("games/murder_mystery_2_specific")
        elseif gameModuleName == "jailbreak" then
            loadModule("games/jailbreak")
        elseif gameModuleName == "piggy" then
            loadModule("games/piggy")
        elseif gameModuleName == "natural_disaster_survival" then
            loadModule("games/natural_disaster_survival")
        elseif gameModuleName == "all_star_tower_defense" then
            loadModule("games/all_star_tower_defense")
        else
            -- Load specific game module if it's not a template and not explicitly handled above
            loadModule("games/" .. gameModuleName)
        end
    else
        print("FC HUB: No specific modules found for PlaceId " .. placeId .. ".")
    end
end

-- Main initialization sequence
local function init()
    loadConfig()
    if loadUILibrary() then
        -- UI is ready, now create the main window and tabs
        local Window = _G.FC_HUB.UI:CreateWindow({
            Name = "FC HUB | Premium Script",
            LoadingTitle = "FC HUB Loading...",
            LoadingSubtitle = "by YourName",
            ConfigurationSaving = {
                Enabled = true,
                FolderName = "FCHubData",
                FileName = "Config"
            }
        })

        _G.FC_HUB.MainWindow = Window

        -- Create a main tab for universal features or game selection
        local MainTab = Window:CreateTab("الرئيسية", 4483362458) -- Home icon
        MainTab:CreateLabel("مرحباً بك في FC HUB!")
        MainTab:CreateLabel("تم تحميل السكريبت بنجاح.")

        -- Store MainTab for universal module to add its elements
        _G.FC_HUB.MainTab = MainTab
        _G.FC_HUB.UniversalTab = MainTab -- Assign MainTab to UniversalTab for universal module access
        _G.FC_HUB.Config.UserKey = _G.FC_HUB.Config.UserKey or "" -- Initialize UserKey in config

        loadGameModules()
        loadModule("modules/security")
        _G.FC_HUB.Security_Init() -- Initialize security module after UI is ready
        loadModule("modules/advanced_exploits")
        _G.FC_HUB.AdvancedExploits_Init() -- Initialize advanced exploits module

        _G.FC_HUB.UI:Notify({
            Title = "تم التحميل!",
            Content = "مرحباً بك في FC HUB",
            Duration = 5,
            Image = 4483362458,
        })
    else
        warn("FC HUB: UI Library not loaded. Running in console-only mode.")
        loadGameModules()
    end
end

init()
